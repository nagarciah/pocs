Message Filter Example
----------------------

This example shows you how to use a Message Filter from Camel. 
To run this example, execute the following command:

mvn compile exec:java -Dexec.mainClass=camelinaction.OrderRouterWithFilter

