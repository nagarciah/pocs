FTP-JMS Routing Example
------------------------

These examples are not runnable in their current form as they reference
an external FTP server.

They are used to explain the Java DSL and show how auto-complete can be
used in your editor to build up a Java DSL route. To load this project in
Eclipse, run

mvn eclipse:eclipse

and import this project by clicking File -> Import -> Existing Projects 
into Workspace in Eclipse and selecting the chapter2/file-jms directory.

