//'use strict';
var app = angular.module('phonebookApp', [/*'ngAnimate'*/]);